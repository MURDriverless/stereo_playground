/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */


#ifndef ERROR_HANDLING_H_
#define ERROR_HANDLING_H_

// TODO: Prefix these values with MEN_ or similar to avoid conflits

#define STATUS_OK           0          /* no error */
#define STATUS_MORE_DATA_AVAILABLE 1   /* there is more data available than could be retrieved i.e. because a buffer was too small */

#define STATUS_ERROR                -1  /* unspecified error */
#define STATUS_ERR_TIMEOUT          -2  /* a timeout has elapsed */
#define STATUS_ERR_DEV_IO           -3  /* an device I/O error occurred */
#define STATUS_ERR_NOT_FOUND        -4  /* whatever was searched for, it was not found */
#define STATUS_ERR_INVALID_ARGUMENT -5  /* at least one invalid argument that was given to the */
#define STATUS_ERR_INSUFFICIENT_MEM -6  /* a memory allocation failed */
#define STATUS_ERR_INVALID_OPERATION -7 /* The reqeusted operation is invalid */

/* i2c */
#define STATUS_I2C_NO_ACK -100

#define IS_ERROR(retval) ((retval) < 0)
#define MEN_IS_SUCCESS(retval) (!IS_ERROR(retval))

#endif /* ERROR_HANDLING_H_ */
