/************************************************************************
* Copyright 2006-2020 Silicon Software GmbH
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License (version 2) as
* published by the Free Software Foundation.
*/


#include "camera_frontend.h"
#include "cxp_frontend.h"
#include "../helpers/error_handling.h"

int camera_frontend_init(struct camera_frontend * self,
                         unsigned int num_physical_ports,
                         void (*reset_physical_port)(struct camera_frontend * self, unsigned int port_num),
                         int (*reset)(struct camera_frontend *),
                         void (*destroy)(struct camera_frontend *),
                         int (*execute_command)(struct camera_frontend *, enum camera_command, union camera_control_input_args *)) {

    if (reset == NULL || destroy == NULL || execute_command == NULL) {
        return STATUS_ERR_INVALID_ARGUMENT;
    }

    self->reset = reset;
    self->reset_physical_port = reset_physical_port;
    self->destroy = destroy;
    self->execute_command = execute_command;

    return STATUS_OK;
}

struct camera_frontend * camera_frontend_factory(enum camera_frontend_type type, struct register_interface* ri, unsigned int num_physical_ports) {
	switch (type) {
	case CAMERA_FRONTEND_CXP:
	{
		struct cxp_frontend * cxp = cxp_frontend_alloc_and_init(ri, num_physical_ports);
		if(cxp != NULL)
		    return upcast(cxp);
		else
		    return NULL;
	}

	default:
	    return NULL;
	}
}
