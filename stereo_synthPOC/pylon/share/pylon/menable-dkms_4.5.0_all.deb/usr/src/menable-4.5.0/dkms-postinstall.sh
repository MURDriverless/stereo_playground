#!/bin/sh

echo "Running Post-Install Script"
DRV_UDEV_DIR="./linux/udev"
/usr/bin/install -m 644 ${DRV_UDEV_DIR}/10-siso.rules /etc/udev/rules.d/
/usr/bin/install -m 755 ${DRV_UDEV_DIR}/men_path_id ${DRV_UDEV_DIR}/men_uiq ${DRV_UDEV_DIR}/men_dma /sbin/

# On Ubuntu 16 at least, logname is missing or broken due to security concerns. The following
# line uses logname, if available, then $SUDO_USER and at last $USER, which seems to be the most 
# portable approach the get the current username
usermod -a -G video $(logname 2>/dev/null || echo "${SUDO_USER:-${USER}}")
