/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#ifndef LIB_BOARDS_ME6_IMPULSE_H
#define LIB_BOARDS_ME6_IMPULSE_H

#include "peripheral_declaration.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ME6_IMPULSE_NUM_I2C_BUSSES 2
extern struct i2c_master_core_declaration me6_impulse_i2c_declaration;

extern struct spi_v2a_declaration me6_impulse_spi_declaration;

#define ME6_IMPULSE_CXP_SP_NUM_UIQS 4
extern struct uiq_declaration me6_impulse_cxp_sp_uiq_declaration[ME6_IMPULSE_CXP_SP_NUM_UIQS];

#define ME6_IMPULSE_CXP_DP_NUM_UIQS 8
extern struct uiq_declaration me6_impulse_cxp_dp_uiq_declaration[ME6_IMPULSE_CXP_DP_NUM_UIQS];

#define ME6_IMPULSE_CXP_QP_NUM_UIQS 16
extern struct uiq_declaration me6_impulse_cxp_qp_uiq_declaration[ME6_IMPULSE_CXP_QP_NUM_UIQS];

/* CXP data registers */
#define ME6_IMPULSE_CXP_REG_CMD_DATA_0 0x809
#define ME6_IMPULSE_CXP_REG_CMD_DATA_1 0x80b
#define ME6_IMPULSE_CXP_REG_CMD_DATA_2 0x80d
#define ME6_IMPULSE_CXP_REG_CMD_DATA_3 0x80f

/* DSN Parts */
#define ME6_IMPULSE_DSN_LOW_STATIC_MAJOR_VERSION_SHIFT 0
#define ME6_IMPULSE_DSN_LOW_STATIC_MAJOR_VERSION_MASK 0x7
#define ME6_IMPULSE_DSN_LOW_STATIC_MINOR_VERSION_SHIFT 11
#define ME6_IMPULSE_DSN_LOW_STATIC_MINOR_VERSION_MASK 0xf

#ifdef __cplusplus
}
#endif

#endif