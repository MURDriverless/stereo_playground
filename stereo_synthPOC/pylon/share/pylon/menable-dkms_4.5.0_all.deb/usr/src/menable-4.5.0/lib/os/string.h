/************************************************************************
* Copyright 2006-2020 Silicon Software GmbH
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License (version 2) as
* published by the Free Software Foundation.
*/


#ifndef LIB_OS_STRING_H_
#define LIB_OS_STRING_H_

#ifdef __linux__

#include "linux/string.h"

#elif defined(_WIN32) || defined(_WIN64)

#include "win/string.h"

#endif

#endif /* LIB_OS_STRING_H_ */
