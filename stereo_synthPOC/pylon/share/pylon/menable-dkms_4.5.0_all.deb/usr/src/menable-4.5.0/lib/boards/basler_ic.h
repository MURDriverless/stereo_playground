/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#ifndef LIB_BOARDS_BASLER_IC_H
#define LIB_BOARDS_BASLER_IC_H

#include "peripheral_declaration.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BASLER_CXP12_IC_1C_NUM_I2C_BUSSES 1
extern struct i2c_master_core_declaration basler_cxp12_ic_1c_i2c_declaration;

#define BASLER_CXP12_IC_1C_NUM_UIQS 4
extern struct uiq_declaration basler_cxp12_ic_1c_uiq_declaration[BASLER_CXP12_IC_1C_NUM_UIQS];

/* CXP data registers */
#define BASLER_CXP12_IC_1C_CXP_REG_CMD_DATA_0 0x809

/* DSN Parts */
#define BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MAJOR_VERSION_SHIFT 0
#define BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MAJOR_VERSION_MASK 0x7
#define BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MINOR_VERSION_SHIFT 11
#define BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MINOR_VERSION_MASK 0xf

/* Feature Checks */
#define BASLER_CXP12_IC_1C_SUPPORTS_CAMERA_FRONTEND(dsn_low) \
    ((((dsn_low >> BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MAJOR_VERSION_SHIFT) & BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MAJOR_VERSION_MASK) > 2) \
     || ((((dsn_low >> BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MAJOR_VERSION_SHIFT) & BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MAJOR_VERSION_MASK) == 1) \
         && (((dsn_low >> BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MINOR_VERSION_SHIFT) & BASLER_CXP12_IC_1C_DSN_LOW_STATIC_MINOR_VERSION_MASK) > 0)))

#ifdef __cplusplus
}
#endif

#endif
