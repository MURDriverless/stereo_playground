/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#include "controller_base.h"

#include "../os/assert.h"

#include "../helpers/error_handling.h"
#include "../helpers/helper.h"

#ifdef DBG_CTRL_BASE

    #ifndef DEBUG
    #define DEBUG
    #endif

    #define DBG_LEVEL 1
    #define DBG_NAME "[controller base] "

#endif
#include "../helpers/dbg.h"

static void cleanup_burst_state(struct controller_base * self) {
    self->current_burst_flags = 0;
    self->is_first_shot = false;
    self->is_last_shot = false;
}

static int write_burst(struct controller_base * self, struct burst_header * bh,
                       const uint8_t * buf, size_t size)
{
    DBG_TRACE_BEGIN_FCT;
    assert(bh->type == BURST_TYPE_WRITE);

    int ret = STATUS_OK;

    self->current_burst_flags = bh->flags & 0xff;
    self->handle_pre_burst_flags(self, bh->flags);

    size_t num_remaining_bytes = size;

    int num_queued_commands = 0;

    while (num_remaining_bytes > 0) {
        self->is_first_shot = (num_remaining_bytes == size);
        self->is_last_shot = (num_remaining_bytes <= self->max_bytes_per_write);

        int bytes_to_write = min(num_remaining_bytes, self->max_bytes_per_write);

        ret = self->write_shot(self, buf, bytes_to_write);
        if (IS_ERROR(ret))
            goto error;

        buf += bytes_to_write;
        num_remaining_bytes -= bytes_to_write;
        ++num_queued_commands;

        if (num_queued_commands % self->write_queue_size == 0) {
            ret = self->wait_for_write_queue_empty(self);
            if (IS_ERROR(ret))
                goto error;
        }
    }

    self->is_first_shot = false;
    self->is_last_shot = false;

    if (num_queued_commands % self->write_queue_size != 0) {
        ret = self->wait_for_write_queue_empty(self);
        if (IS_ERROR(ret))
            goto error;
    }

    self->handle_post_burst_flags(self, bh->flags);
    self->current_burst_flags = 0;

    DBG_TRACE_END_FCT;
    return STATUS_OK;

error:
    cleanup_burst_state(self);
    DBG_TRACE_END_FCT;
    return STATUS_ERROR;
}

static int read_burst(struct controller_base * self,
                      struct burst_header * bh,
                      uint8_t * buf, size_t size)
{
    DBG_TRACE_BEGIN_FCT;
    assert(bh->type == BURST_TYPE_READ);

    int ret = STATUS_OK;

    self->current_burst_flags = bh->flags & 0xff;
    self->handle_pre_burst_flags(self, bh->flags);

    size_t bytes_to_request = size;
    size_t bytes_to_read = 0;

    /* queue as many read operations as possible */
    for (size_t i = 0; i < self->read_queue_size && bytes_to_request > 0; ++i) {
        int num_bytes = min(bytes_to_request, self->max_bytes_per_read);
        bytes_to_request -= num_bytes;
        bytes_to_read += num_bytes;

        self->is_first_shot = (i == 0);
        self->is_last_shot = (bytes_to_read == size);

        ret = self->request_read(self, num_bytes);
        if (IS_ERROR(ret))
            goto error;

    }

    /* read data, request further data if required */
    self->is_first_shot = true;
    while (bytes_to_read > 0) {
        self->is_last_shot = (bytes_to_request == 0 && bytes_to_read <= self->max_bytes_per_read);
        int num_bytes = min(bytes_to_read, self->max_bytes_per_read);

        ret = self->read_shot(self, buf, num_bytes);
        if (IS_ERROR(ret))
            goto error;

        buf += num_bytes;
        bytes_to_read -= num_bytes;
        self->is_first_shot = false;

        if (bytes_to_request > 0) {
            int num_bytes = min(bytes_to_request, self->max_bytes_per_read);

            ret = self->request_read(self, num_bytes);
            if (IS_ERROR(ret))
                goto error;

            bytes_to_request -= num_bytes;
            bytes_to_read += num_bytes;
        }
    }
    self->is_last_shot = false;

    assert(bytes_to_request == 0);
    assert(bytes_to_read == 0);

    self->handle_post_burst_flags(self, bh->flags);
    self->current_burst_flags = 0;

    DBG_TRACE_END_FCT;
    return STATUS_OK;

error:
    cleanup_burst_state(self);
    DBG_TRACE_END_FCT;
    return STATUS_ERROR;
}

static int state_change_burst(struct controller_base * self, struct burst_header * bh) {
    int ret = self->handle_pre_burst_flags(self, bh->flags);

    /* TODO: What happens if the state change is not successful? */
    if (ret != STATUS_OK) {
        return ret;
    }

    return self->handle_post_burst_flags(self, bh->flags);
}

static bool are_burst_flags_set(struct controller_base * self, uint8_t flags) {
    return (self->current_burst_flags & flags) == flags;
}

static void destroy(struct controller_base * self) {
    self->cleanup(self);
}

void controller_base_init(struct controller_base * ctrl,
                          struct register_interface * ri,
                          user_mode_lock * lock,
                          int read_queue_size,
                          int max_bytes_per_read,
                          int write_queue_size,
                          int max_bytes_per_write,
                          int (*handle_pre_burst_flags)(struct controller_base * ctrl, uint32_t flags),
                          int (*handle_post_burst_flags)(struct controller_base * ctrl, uint32_t flags),
                          int (*write_shot)(struct controller_base * ctrl, const uint8_t * buf, int num_bytes),
                          int (*request_read)(struct controller_base * ctrl, size_t num_bytes),
                          int (*read_shot)(struct controller_base * ctrl, uint8_t * buffer, size_t num_bytes),
                          int (*wait_for_write_queue_empty)(struct controller_base * ctrl),
                          void (*burst_aborted)(struct controller_base * self),
                          void (*cleanup)(struct controller_base * self))
{
    DBG_TRACE_BEGIN_FCT;
    ctrl->register_interface = ri;
    ctrl->lock = lock;

    ctrl->read_queue_size = read_queue_size;
    ctrl->max_bytes_per_read = max_bytes_per_read;

    ctrl->write_queue_size = write_queue_size;
    ctrl->max_bytes_per_write = max_bytes_per_write;

    ctrl->write_burst = write_burst;
    ctrl->read_burst = read_burst;
    ctrl->state_change_burst = state_change_burst;
    ctrl->are_burst_flags_set = are_burst_flags_set;
    ctrl->destroy = destroy;

    ctrl->handle_pre_burst_flags = handle_pre_burst_flags;
    ctrl->handle_post_burst_flags = handle_post_burst_flags;
    ctrl->write_shot = write_shot;
    ctrl->request_read = request_read;
    ctrl->read_shot = read_shot;
    ctrl->wait_for_write_queue_empty = wait_for_write_queue_empty;
    ctrl->burst_aborted = burst_aborted;
    ctrl->cleanup = cleanup;

    ctrl->current_burst_flags = 0;
    ctrl->is_first_shot = false;
    ctrl->is_last_shot = false;
    DBG_TRACE_END_FCT;
}
