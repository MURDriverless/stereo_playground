/************************************************************************
* Copyright 2006-2020 Silicon Software GmbH
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License (version 2) as
* published by the Free Software Foundation.
*/

#ifndef LIB_OS_TIME_H_
#define LIB_OS_TIME_H_

#include "types.h"

#if defined(__linux__)

#include "linux/delay.h"

#elif defined(_WIN32) || defined(_WIN64)

#include "win/delay.h"

#endif


/**
 * Get the current milliseconds relative to an unknown, but fixed point in the past.
 * It is guaranteed that while the system is running, the same point is used.
 *
 * @return the current milliseconds
 */
uint64_t get_current_msecs(void);

#endif /* LIB_OS_TIME_H_ */
