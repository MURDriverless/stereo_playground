/************************************************************************
* Copyright 2006-2020 Silicon Software GmbH
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License (version 2) as
* published by the Free Software Foundation.
*/



#ifndef LIB_OS_WIN_KERNEL_TYPES_H_
#define LIB_OS_WIN_KERNEL_TYPES_H_

#include <intsafe.h>
#include <ntdef.h>
#include <wdm.h>

#define int64_t     INT64
#define int32_t     INT32
#define int16_t     INT16
#define int8_t      INT8

#define uint64_t    UINT64
#define uint32_t    UINT32
#define uint16_t    UINT16
#define uint8_t     UINT8

#ifndef __cplusplus
    #define bool    BOOLEAN
    #define true    1
    #define false   0
#endif

typedef FAST_MUTEX user_mode_lock;

#endif /* LIB_OS_WIN_KERNEL_TYPES_H_ */
