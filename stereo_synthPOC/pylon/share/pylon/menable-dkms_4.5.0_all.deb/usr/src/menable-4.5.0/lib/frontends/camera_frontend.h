/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#ifndef _MEN_LIB_FRONTENDS_CAMERA_FRONTEND_H_
#define _MEN_LIB_FRONTENDS_CAMERA_FRONTEND_H_

#include <lib/ioctl_interface/camera.h>
#include <lib/fpga/register_interface.h>
#include <lib/os/types.h>
#include <lib/helpers/error_handling.h>

#define CAMERA_FRONTEND_VERSION 1

enum camera_frontend_type {
    CAMERA_FRONTEND_UNKNOWN,
    CAMERA_FRONTEND_CXP
};

/**
 * Abstract base class for all camera frontends.
 */
struct camera_frontend {

    unsigned int num_physical_ports;

    void (*reset_physical_port)(struct camera_frontend * self, unsigned int port_num);

    /**
     * Initialise frontend and all ports to default state.
     */
    int (*reset)(struct camera_frontend * self);

    /**
     * Destructor.
     */
    void (*destroy)(struct camera_frontend * self);

    /**
     * Dispatcher for command execution
     */
    int (*execute_command)(struct camera_frontend * self, enum camera_command cmd, union camera_control_input_args * args);
};

/**
 * Factory for camera frontends.
 */
struct camera_frontend * camera_frontend_factory(enum camera_frontend_type, struct register_interface * ri, unsigned int num_physical_ports);

/**
 * Constructor for the base class.

 * @attention: Do not use outside a subclass.
 */
int camera_frontend_init(struct camera_frontend * self,
                         unsigned int num_physical_ports,
                         void (*reset_physical_port)(struct camera_frontend * self, unsigned int port_num),
                         int (*reset)(struct camera_frontend *),
                         void (*destroy)(struct camera_frontend *),
                         int (*execute_command)(struct camera_frontend *, enum camera_command, union camera_control_input_args *));

#endif
