/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#ifndef UIQ_H
#define UIQ_H

#include <linux/completion.h>
#include <linux/device.h>
#include <linux/spinlock.h>
#include <linux/types.h>

#include <lib/uiq/uiq_defines.h>

struct siso_menable;
struct register_interface;

struct menable_uiq {
	struct device dev;
	struct siso_menable *parent;

	/* simple ringbuffer. Memory is allocated on demand */
	unsigned int reg_offs; /* address of hardware register */
	uint32_t *data;        /* data buffer */
	unsigned int rindex;   /* read index */
	unsigned int fill;     /* number of entries occupied starting at rindex */
	unsigned int length;   /* index wraparound (sort of ARRAY_SIZE(data)) */
	unsigned int lost;     /* number of entries lost by overflow */
	unsigned int irqcnt;   /* number of interrupts */
	unsigned int cpltodo;  /* number of entries cpl still waits for */
	unsigned char chan;    /* own channel number */
	unsigned int id;       /* uiq identifier (packet type + source id) */
	unsigned char burst;   /* max number of entries to write on burst */
	unsigned int irqack_offs; /* irq acknowledge register offset */
	unsigned char ackbit;  /* bit in irqack */
	bool running;          /* still waiting for ACK */
	unsigned int type;     /* protocol for the uiq */
	bool loss_error;       /* the last value(s) were lost */
	unsigned long cpltimeout;  /* timeout for read */
	struct completion cpl;     /* wait for timeout */
	spinlock_t lock;
};

extern struct menable_uiq *men_uiq_init(struct siso_menable *parent, int chan, unsigned int id,
		unsigned int type, unsigned int reg_offs, unsigned char burst);
extern int men_scale_uiq(struct menable_uiq *uiq, const unsigned int len);
extern void men_uiq_remove(struct menable_uiq *);
extern void uiq_irq(struct menable_uiq *uiq, struct timespec *ts, bool *have_ts);
extern void men_del_uiqs(struct siso_menable *men, const unsigned int fpga);

extern bool men_uiq_pop(struct menable_uiq *uiq, struct timespec *ts, bool *have_ts, enum uiq_protocol protocol);
extern bool men_uiq_push(struct menable_uiq *uiq);

extern struct class *menable_uiq_class;
extern struct device_attribute men_uiq_attributes[6];

#endif /* UIQ_H */
