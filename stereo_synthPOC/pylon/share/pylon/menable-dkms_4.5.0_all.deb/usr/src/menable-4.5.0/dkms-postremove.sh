#!/bin/sh

echo "Running DKMS Post-Remove Script"
rm -f /etc/udev/rules.d/10-siso.rules
rm -f /sbin/men_path_id /sbin/men_uiq /sbin/men_dma
