/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#include "i2c_bus_controller.h"
#include "../os/assert.h"
#include "../helpers/error_handling.h"

static int i2c_read_burst(struct controller_base * base, struct burst_header * bh, uint8_t * buf, size_t size) {
    struct i2c_bus_controller * self = downcast(base, struct i2c_bus_controller);
    struct controller_base * core_base = upcast(self->i2c_core);

    self->i2c_core->activate_bank(self->i2c_core, self->bank_number);
    return core_base->read_burst(core_base, bh, buf, size);
}

static int i2c_write_burst(struct controller_base * base, struct burst_header * bh, const uint8_t * buf, size_t size) {
    struct i2c_bus_controller * self = downcast(base, struct i2c_bus_controller);
    struct controller_base * core_base = upcast(self->i2c_core);

    self->i2c_core->activate_bank(self->i2c_core, self->bank_number);
    return core_base->write_burst(core_base, bh, buf, size);
}

static int i2c_state_change_burst(struct controller_base * base, struct burst_header * bh) {
    struct i2c_bus_controller * self = downcast(base, struct i2c_bus_controller);
    struct controller_base * core_base = upcast(self->i2c_core);

    self->i2c_core->activate_bank(self->i2c_core, self->bank_number);
    return core_base->state_change_burst(core_base, bh);
}

static bool i2c_are_burst_flags_set(struct controller_base * base, uint8_t flags) {
    struct i2c_bus_controller * self = downcast(base, struct i2c_bus_controller);
    struct controller_base * core_base = upcast(self->i2c_core);

    return core_base->are_burst_flags_set(core_base, flags);
}

static void i2c_destroy(struct controller_base * base) {
    struct i2c_bus_controller * self = downcast(base, struct i2c_bus_controller);
    struct controller_base * core_base = upcast(self->i2c_core);

    core_base->destroy(core_base);
}

int i2c_bus_controller_init(struct i2c_bus_controller * ctrl,
                            struct i2c_master_core * i2c_core,
                            uint8_t bank_number) {

    assert_msg(bank_number < 8, "Invalid bank number\n");

    ctrl->i2c_core = i2c_core;
    ctrl->bank_number = bank_number;


    /*
     * redirect then "non-virtual" member functions of the base of this instance
     * to the base of the i2c_master_core instance.
     */
    /* TODO This is errorprone! If new functions are defined for the controller_base, these
     *      also have to be redirected here. Can't we do any better?
     */
    struct controller_base * base = upcast(ctrl);
    base->lock = i2c_core->base_type.lock;
    base->read_burst = i2c_read_burst;
    base->write_burst = i2c_write_burst;
    base->state_change_burst = i2c_state_change_burst;
    base->are_burst_flags_set = i2c_are_burst_flags_set;
    base->destroy = i2c_destroy;

    return STATUS_OK;
}
