/************************************************************************
 * Copyright 2006-2020 Silicon Software GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (version 2) as
 * published by the Free Software Foundation.
 */

#ifndef LIB_BOARDS_ME6_DEFINES_H
#define LIB_BOARDS_ME6_DEFINES_H

#include <multichar.h>

#define ME6_REG_BOARD_STATUS 0x0000 /**< Board status register */
#define GETFIRMWAREVERSION(x) (((x) & 0xff00) | (((x) >> 16) & 0xff))

#define ME6_REG_BOARD_ID 0x0001 /**< Board ID register */

#define ME6_REG_IRQ_STATUS 0x0003 /**< IRQ status register (only used in single-MSIX mode) */
#define ME6_IRQ_VEC_ALARMS 0x01 /**< Level-triggered interrupt sources */
#define ME6_IRQ_VEC_EVENT  0x02 /**< Events/UIQs/Messaging Channel */
#define ME6_IRQ_VEC_DMA_0  0x04 /**< DMA 0 */
#define ME6_IRQ_VEC_DMA_1  0x08 /**< DMA 1 */
#define ME6_IRQ_VEC_DMA_2  0x10 /**< DMA 2 */
#define ME6_IRQ_VEC_DMA_3  0x20 /**< DMA 3 */
#define ME6_IRQ_VALID_MASK 0x3f /**< Valid IRQ sources */

#define ME6_REG_IRQ_ALARMS_ENABLE 0x0004 /**< W: Level-triggered interrupt sources enable register */
#define ME6_REG_IRQ_ALARMS_STATUS 0x0004 /**< R: Level-triggered interrupt sources status register */
#define ME6_ALARM_OVERTEMP  0x1
#define ME6_ALARM_SOFTWARE  0x2
#define ME6_ABACUS_ALARM_PHY_0_MGM 0x4
#define ME6_ABACUS_ALARM_PHY_1_MGM 0x8
#define ME6_ABACUS_ALARM_PHY_2_MGM 0x10
#define ME6_ABACUS_ALARM_PHY_3_MGM 0x20
#define ME6_ABACUS_ALARM_POE_FAULT 0x40

#define ME6_REG_IRQ_SOFTWARE_TRIGGER 0x000D /**< W: Write '1' to trigger software interrupt */

#define ME6_REG_IRQ_EVENT_COUNT 0x0005 /**< Number of events */
#define ME6_IRQ_EVENT_OVERFLOW 0x1 /**< Overflow of event counter */
#define ME6_IRQ_EVENT_GET_COUNT(x) (((x) >> 1) & 0xffff)

#define ME6_REG_IRQ_DMA_0_COUNT 0x0007 /**< Number of pending DMA 0 interrupts */
#define ME6_REG_IRQ_DMA_1_COUNT 0x0008 /**< Number of pending DMA 1 interrupts */
#define ME6_REG_IRQ_DMA_2_COUNT 0x0009 /**< Number of pending DMA 2 interrupts */
#define ME6_REG_IRQ_DMA_3_COUNT 0x000A /**< Number of pending DMA 3 interrupts */
#define ME6_IRQ_DMA_COUNT_NEXT 4
#define ME6_REG_IRQ_DMA_COUNT_FOR_CHANNEL_IDX(chan) (ME6_REG_IRQ_DMA_0_COUNT + (chan) * ME6_IRQ_DMA_COUNT_NEXT)
#define ME6_IRQ_DMA_OVERFLOW 0x1 /**< Overflow of DMA interrupt counter */
#define ME6_IRQ_DMA_GET_COUNT(x) (((x) >> 1) & 0xff)

#define ME6_REG_LED_CONTROL 0x0012

#define ME6_MAX_NUM_DMAS          4      /**< Maximum number of DMA channels */
#define ME6_REG_NUM_DMA_CHANNELS  0x0002 /**< Number of DMA channels */
#define ME6_REG_DMA_BASE          0x0110 /**< DMA engine base address */
#define ME6_DMA_CHAN_OFFSET       0x000A /**< Add n*offs to DMA_BASE for base of channel n*/

/* The following addresses are relative to channel base */
#define ME6_REG_DMA_CONTROL       0x0000 /**< W: DMA engine control register */
#define ME6_REG_DMA_STATUS        0x0000 /**< R: DMA engine status register  */
#define ME6_REG_DMA_SGL_ADDR_LOW  0x0001 /**< W: SGL FIFO low address */
#define ME6_REG_DMA_SGL_ADDR_HIGH 0x0002 /**< W: SGL FIFO high address */
#define ME6_REG_DMA_TYPE          0x0003 /**< R: DMA type */
#define ME6_REG_DMA_LENGTH        0x0004 /**< R: DMA transfer length FIFO */
#define ME6_REG_DMA_TAG           0x0005 /**< R: DMA tag FIFO */

#define ME6_DMA_CTRL_RESET  0x2 /**< Reset DMA engine */
#define ME6_DMA_CTRL_ENABLE 0x1 /**< Enable DMA engine */

#define ME6_DMA_STAT_RUNNING 0x4 /**< DMA engine is running */
#define ME6_DMA_STAT_TIMEOUT 100000

#define ME6_DMA_TYPE_TO_PC   0x1 /**< Dma to PC */
#define ME6_DMA_TYPE_FROM_PC 0x2 /**< Dma from PC */

/* Event data register */
#define ME6_REG_IRQ_EVENT_DATA 0x0006
#define ME6_IRQ_EVENT_GET_PACKET_LENGTH(x) (((x) >> 16) & 0xffff)
#define ME6_IRQ_EVENT_GET_PACKET_TYPE(x) (((x) >> 8) & 0xff)
#define ME6_EVENT_PACKET_TYPE_NATIVE 0x0
#define ME6_EVENT_PACKET_TYPE_RAW_READ 0x1
#define ME6_EVENT_PACKET_TYPE_WRITE_DONE 0x2
#define ME6_IRQ_EVENT_GET_PACKET_SOURCE(x) ((x)&0xff)
#define ME6_IRQ_EVENT_GET_PACKET_ID(x) ((x)&0xffff)

/* SPI controller */
#define ME6_REG_SPI_CONTROL 0x1002
#define ME6_SPI0_PEIPHERAL_ID MULTICHAR32('S', 'P', 'I', '0')

/* I2C controller */
#define ME6_REG_I2C_ADDRESS 0x1005
#define ME6_REG_I2C_WRITE   0x1006
#define ME6_REG_I2C_READ    0x1006
#define ME6_FW_CLOCK_FREQ 300000000 /* 300 MHz */
#define ME6_I2C_FREQ         400000 /* 400 KHz */
#define ME6_I2C_FREQ_POE      10000 /*  10 KHz (POE/PSE on Abacus) */
#define ME6_I2C_FREQ_EXT     100000 /* 100 KHz */
#define ME6_I2C_NUM_SAFETY_WRITES 1
#define ME6_I2C0_PERIPHERAL_ID MULTICHAR32('I', '2', 'C', '0')
#define ME6_I2C1_PERIPHERAL_ID MULTICHAR32('I', '2', 'C', '1')

/* BoardStatus DNA not ready */
#define ME6_BOARD_STATUS_DNA_MAX_RETRIES 100
#define ME6_BOARD_STATUS_DNA_NOT_READY 0x10000

/* DNA registers */
#define ME6_REG_FPGA_DNA_0 0x1012
#define ME6_REG_FPGA_DNA_1 0x1013
#define ME6_REG_FPGA_DNA_2 0x1014

#endif /* LIB_BOARDS_ME6_DEFINES_H */
