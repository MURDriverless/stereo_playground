/************************************************************************
* Copyright 2006-2020 Silicon Software GmbH
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License (version 2) as
* published by the Free Software Foundation.
*/

#if defined(DEBUG_IRQS) && !defined(DEBUG)
#define DEBUG
#endif

#include "menable.h"

#include <linux/completion.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/dmapool.h>
#include <linux/err.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/sched.h>
#include <linux/pci.h>
#include <linux/msi.h>
#include <linux/vmalloc.h>
#include <stdbool.h>

#include <lib/helpers/helper.h>
#include <lib/boards/peripheral_declaration.h>
#include <lib/helpers/dbg.h>

#include "menable6.h"
#include "menable_ioctl.h"
#include "sisoboards.h"
#include "uiq.h"

#include "linux_version.h"

static DEVICE_ATTR(design_crc, 0660, men_get_des_val, men_set_des_val);

static struct attribute *me6_attributes[2] = {
    &dev_attr_design_crc.attr,
    NULL
};

struct attribute_group me6_attribute_group = { .attrs = me6_attributes };

static const struct attribute_group *me6_attribute_groups[2] = {
    &me6_attribute_group,
    NULL
};

const struct attribute_group ** me6_init_attribute_groups(struct siso_menable *men)
{
    if (SisoBoardIsAbacus(men->pci_device_id)) {
        return me6_abacus_init_attribute_groups(men);
    }
    return me6_attribute_groups;
}

static int
me6_update_board_status(struct siso_menable *men)
{
    int ret = 0;
    u32 ctrl;
    ret = MCapRegRead(&men->d6->mdev, MCAP_CONTROL, &ctrl);
    if (ret == 0) {
        if ((ctrl & MCAP_CTRL_DESIGN_SWITCH_MASK) != 0) {
            // We probe the register interface here, so force activate it
            men->register_interface.activate(&men->register_interface);
            men->config_ex = men->register_interface.read(&men->register_interface, ME6_REG_BOARD_ID);
            DBG_STMT(dev_dbg(&men->dev, "PCIe interface is active, Board Status reads as %08x\n", men->config_ex));
        } else {
            men->config = men->config_ex = (unsigned int) -1;
            DBG_STMT(dev_dbg(&men->dev, "PCIe interface is inactive\n"));
        }
    } else {
        men->config = men->config_ex = (unsigned int) -1;
        dev_err(&men->dev, "failed to read MCAP control register\n");
    }

    if (men->config_ex == (unsigned int) -1 || men->config_ex == 0) {
        dev_info(&men->dev, "device is not configured\n");
        men->register_interface.deactivate(&men->register_interface);
        if (men_get_state(men) > BOARD_STATE_UNINITIALISED) {
            ret = men_set_state(men, BOARD_STATE_DEAD);
        } else {
            ret = men_set_state(men, BOARD_STATE_UNINITIALISED);
        }
    } else {
        dev_info(&men->dev, "device is configured\n");
        if (men_get_state(men) < BOARD_STATE_READY) {
            ret = men_set_state(men, BOARD_STATE_READY);
        }

        // Poll for FPGA DNA ready
        unsigned int i;
        for (i = 0, men->config = (unsigned int)-1; (i < ME6_BOARD_STATUS_DNA_MAX_RETRIES) && ((men->config & ME6_BOARD_STATUS_DNA_NOT_READY) != 0); ++i) {
            men->config = men->register_interface.read(&men->register_interface, ME6_REG_BOARD_STATUS);
        }
        if ((men->config & ME6_BOARD_STATUS_DNA_NOT_READY) == 0) {
            DBG_STMT(dev_dbg(&men->dev, "device FPGA DNA is available after %u cycle(s)\n", i));
        }
        else {
            dev_err(&men->dev, "device FPGA DNA is not available; timed out\n");
        }

        men->fpga_dna[0] = men->register_interface.read(&men->register_interface, ME6_REG_FPGA_DNA_0);
        men->fpga_dna[1] = men->register_interface.read(&men->register_interface, ME6_REG_FPGA_DNA_1);
        men->fpga_dna[2] = men->register_interface.read(&men->register_interface, ME6_REG_FPGA_DNA_2);
    }

    return ret;
}

static struct me_notification_handler *
me6_create_notify_handler(struct siso_menable *men)
{
    struct me_notification_handler *bh;
    unsigned long flags = 0;

#ifdef ENABLE_DEBUG_MSG
    printk(KERN_INFO "[%d %d]: creating Notify Handler\n", current->parent->pid, current->pid);
#endif

    bh = kzalloc(sizeof(*bh), GFP_USER);
    if (bh == NULL) {
        return NULL;
    }

    INIT_LIST_HEAD(&bh->node);

    bh->pid = current->pid;
    bh->ppid = current->parent->pid;
    bh->quit_requested = false;
    init_completion(&bh->notification_available);

    spin_lock_irqsave(&men->d6->notification_data_lock, flags);
    {
        bh->notification_time_stamp = men->d6->notification_time_stamp;
    }
    spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);

    spin_lock(&men->d6->notification_handler_headlock);
    {
        list_add_tail(&bh->node, &men->d6->notification_handler_heads);
    }
    spin_unlock(&men->d6->notification_handler_headlock);

    return bh;
}

static void
me6_free_notify_handler(struct siso_menable *men,
        struct me_notification_handler *bh)
{
    BUG_ON(in_interrupt());

#ifdef ENABLE_DEBUG_MSG
    printk(KERN_INFO "[%d %d]: removing Notify Handler\n", bh->ppid, bh->pid);
#endif

    spin_lock(&men->d6->notification_handler_headlock);
    {
        __list_del_entry(&bh->node);
    }
    spin_unlock(&men->d6->notification_handler_headlock);

    kfree(bh);
}

static struct me_notification_handler *
me6_get_notify_handler(struct siso_menable *men, const unsigned int ppid,
        const unsigned int pid)
{
    struct me_notification_handler *res;
    bool found = false;

    //printk(KERN_INFO "[%d %d]: getting notify_handler\n", ppid, pid);

    spin_lock(&men->d6->notification_handler_headlock);
    {
        list_for_each_entry(res, &men->d6->notification_handler_heads, node) {
            if ((res->pid == pid) && (res->ppid == ppid)) {
                found = true;
                break;
            }
        }
    }
    spin_unlock(&men->d6->notification_handler_headlock);

    if (found) {
        return res;
    } else {
#ifdef ENABLE_DEBUG_MSG
        printk(KERN_INFO "[%d %d]: no notify_handler found\n", ppid, pid);
#endif
        return NULL;
    }
}

static void
me6_ack_alarms(struct siso_menable *men, unsigned long alarms)
{
    unsigned long flags = 0;

    spin_lock_irqsave(&men->d6->notification_data_lock, flags);
    {
        men->d6->alarms_status &= ~alarms;
        if (men->d6->alarms_status == 0) {
            men->d6->notifications &= ~NOTIFICATION_DEVICE_ALARM;
        }
        men->d6->alarms_enabled |= alarms;
        men->register_interface.write(&men->register_interface, ME6_REG_IRQ_ALARMS_ENABLE, men->d6->alarms_enabled);
    }
    spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);
}

static int
me6_ioctl(struct siso_menable *men, const unsigned int cmd,
        const unsigned int size, unsigned long arg)
{
    int ret = 0;
    unsigned long flags = 0;

#ifdef ENABLE_DEBUG_MSG
     printk(KERN_INFO "[%d]: me6_ioctl (cmd = 0x%X, arg = 0x%X)\n", current->pid, cmd, arg);
#endif
    switch (cmd) {
    case IOCTL_PP_CONTROL:
        {
            unsigned long flags = 0;

            if (size != 0) {
                warn_wrong_iosize(men, cmd, 0);
                return -EINVAL;
            }

            spin_lock_irqsave(&men->designlock, flags);
            {
                if (men->design_changing) {
                    spin_unlock_irqrestore(&men->designlock, flags);
                    return -EBUSY;
                }

                men->design_changing = true;
            }
            spin_unlock_irqrestore(&men->designlock, flags);

            /* TODO: FPGA Master Management */
            switch (arg) {
            case 0:
                break;
            case 1:
                break;
            default:
                ret = -EINVAL;
            }

            spin_lock_irqsave(&men->designlock, flags);
            {
                men->design_changing = false;
            }
            spin_unlock_irqrestore(&men->designlock, flags);
            return ret;
        }

    case IOCTL_EX_CONFIGURE_FPGA:
        {
            struct men_configure_fpga conf;
            uint32_t * data = NULL;
            int len = 0;

            if (size < sizeof(conf)) {
                warn_wrong_iosize(men, cmd, 0);
                return -EINVAL;
            }

            if (copy_from_user(&conf, (const void __user *) arg, sizeof(conf))) {
                dev_err(&men->dev, "failed to copy ioctl data from user");
                return -EFAULT;
            }

            if (conf._size < sizeof(conf) || conf._version < 1 || conf.length == 0) {
                dev_err(&men->dev, "invalid parameters in ioctl data");
                return -EINVAL;
            }

            len = conf.length / sizeof(uint32_t);
            data = vmalloc(conf.length);
            if (!data) {
                dev_err(&men->dev, "failed to allocate memory");
                return -ENOMEM;
            }

            if (copy_from_user(data, ((const u8 __user *) conf.buffer_address), conf.length)) {
                vfree(data);
                dev_err(&men->dev, "failed to copy configuration data from user");
                return -EFAULT;
            }

            if (men_get_state(men) > BOARD_STATE_UNINITIALISED) {
                men->stopirq(men);
                men->d6->cleanup_peripherals(men->d6);
                men_set_state(men, BOARD_STATE_UNINITIALISED);
            }

            if ((conf.flags & CONFIGURE_ME6_BITSTREAM_TYPE_MASK) == CONFIGURE_ME6_PARTIAL_BITSTREAM) {
                dev_dbg(&men->dev, "partial reconfiguration, data length %d bytes\n", len);
                ret = MCapWritePartialBitStream(&men->d6->mdev, data, len,
                                                (conf.flags & CONFIGURE_ME6_SWAP_BYTES) != 0 ? 1 : 0);
            } else {
                dev_dbg(&men->dev, "full reconfiguration, data length %d bytes\n", len);
                ret = MCapWriteBitStream(&men->d6->mdev, data, len,
                                         (conf.flags & CONFIGURE_ME6_SWAP_BYTES) != 0 ? 1 : 0);
            }
            vfree(data);

            if (ret == 0 && (conf.flags & CONFIGURE_ME6_DESIGN_SWITCH) != 0) {
                dev_dbg(&men->dev, "activating design switch\n");
                u32 ctrl = 0;
                ret = MCapRegRead(&men->d6->mdev, MCAP_CONTROL, &ctrl);
                if (ret == 0) {
                    ret = MCapRegWrite(&men->d6->mdev, MCAP_CONTROL, ctrl | MCAP_CTRL_DESIGN_SWITCH_MASK);
                }
            }

            if (ret == 0) {
                ret = me6_update_board_status(men);
            }

            if (ret == 0 && men_get_state(men) >= BOARD_STATE_READY) {
                ret = men->d6->init_peripherals(men->d6);
                if (ret == 0)
                    men->startirq(men);
            }

            return ret;
        }

    case IOCTL_EX_DEVICE_CONTROL:
        {
            struct men_device_control_i ctrl;
            struct men_device_control_o_v2 reply;
            unsigned long leds;
            struct me_notification_handler * handler;
            int result = 0;
            long wakeup_time = msecs_to_jiffies(250);

            if (size < sizeof(ctrl)) {
                warn_wrong_iosize(men, cmd, sizeof(ctrl));
                return -EINVAL;
            }

            if (copy_from_user(&ctrl, (void __user *) arg, sizeof(ctrl))) {
                return -EFAULT;
            }

            if (ctrl._size > size) {
                warn_wrong_iosize(men, cmd, sizeof(ctrl));
                return -EINVAL;
            }

            switch (ctrl.command) {
            case DEVCTRL_SET_LEDS:
                men->register_interface.write(&men->register_interface, ME6_REG_LED_CONTROL, ctrl.args.set_leds.led_status);
                break;

            case DEVCTRL_GET_LEDS:
                if (size < sizeof(reply)) {
                    warn_wrong_iosize(men, cmd, sizeof(reply));
                    return -EINVAL;
                }

                leds = men->register_interface.read(&men->register_interface, ME6_REG_LED_CONTROL);
                reply.args.get_leds.led_present = leds & 0xFFFF;
                reply.args.get_leds.led_status = (leds >> 16) & 0xFFFF;

                if (copy_to_user((void __user *) arg, &reply, sizeof(reply))) {
                    return -EFAULT;
                }

                break;

            case DEVCTRL_GET_ASYNC_NOTIFY:
                {
                    unsigned long notifications;
                    unsigned long notifications_ts;
                    unsigned long alarms_status;

                    spin_lock_irqsave(&men->d6->notification_data_lock, flags);
                    {
                        notifications = men->d6->notifications;
                        notifications_ts = men->d6->notification_time_stamp;
                    }
                    spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);

                    if (size < sizeof(reply)) {
                        warn_wrong_iosize(men, cmd, sizeof(reply));
                        return -EINVAL;
                    }

                    handler = me6_get_notify_handler(men, current->parent->pid, current->pid);
                    if (handler == NULL) {
                        handler = me6_create_notify_handler(men);
                        if (handler == NULL) {
                            return -ENOMEM;
                        }
                    }

                    if ((!handler->quit_requested)
                            && ((handler->notification_time_stamp == notifications_ts) || (!notifications))) {
                        // Wait until a notification is received
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 35)
                        wakeup_time = wait_for_completion_killable_timeout(&handler->notification_available, msecs_to_jiffies(250));
#else
                        wakeup_time = wait_for_completion_interruptible_timeout(&handler->notification_available, msecs_to_jiffies(250));
#endif
                    }

                    spin_lock_irqsave(&men->d6->notification_data_lock, flags);
                    {
                        notifications = men->d6->notifications;
                        notifications_ts = men->d6->notification_time_stamp;
                        alarms_status = men->d6->alarms_status;
                    }
                    spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);

                    reply.args.get_async_event.pl = 0;
                    reply.args.get_async_event.ph = 0;

                    if (handler->quit_requested) {
                        DBG_STMT(pr_debug("Quit requested\n"));

                        reply.args.get_async_event.event = DEVCTRL_ASYNC_NOTIFY_DRIVER_CLOSED;
                        if (copy_to_user((void __user *) arg, &reply, sizeof(reply))) {
                            return -EFAULT;
                        }
                        me6_free_notify_handler(men, handler);
                        handler = NULL;
                    } else if (handler->notification_time_stamp != notifications_ts) {

                        handler->notification_time_stamp = notifications_ts;
                        // We might have received 10000 completions and just started
                        // to handle them now, so that we must reset the completion struct now.
                        // Otherwise, we will handle the same interrupt 10000 times.
                        reinit_completion(&handler->notification_available);

                        if (notifications) {
                            if (notifications & NOTIFICATION_DEVICE_REMOVED) {
                                me6_free_notify_handler(men, handler);
                                handler = NULL;
                                reply.args.get_async_event.event = DEVCTRL_ASYNC_NOTIFY_DEVICE_REMOVED;
                            } else if (notifications & NOTIFICATION_DEVICE_ALARM) {
                                reply.args.get_async_event.event = DEVCTRL_ASYNC_NOTIFY_DEVICE_ALARM;
                                reply.args.get_async_event.pl = men->d6->alarms_to_event_pl(alarms_status);
                            } else if (notifications & NOTIFICATION_DRIVER_CLOSED) {
                                reply.args.get_async_event.event = DEVCTRL_ASYNC_NOTIFY_DRIVER_CLOSED;
                            } else if (notifications & NOTIFICATION_DEVICE_ADDED) {
                                reply.args.get_async_event.event = DEVCTRL_ASYNC_NOTIFY_DEVICE_ADDED;
                            }
                        } else { // No notification happened, but only timestamp updated.
                            // No notification is availble, so that it's better to return timeout
                            result = -ETIMEDOUT;
                        }
                    } else if (wakeup_time == 0) { // Timeout
                        result = -ETIMEDOUT;
                    } else if (wakeup_time > 0) { // someone sent a complete, but we don't know who ! (Should never happen)
                        result = -ETIMEDOUT;
                    } else { // (wakeup_time < 0) // Sleeping process is interrupted !
                        result = -EFAULT;
                    }

                    if (result == 0) {
                        if (copy_to_user((void __user *) arg, &reply, sizeof(reply))) {
                            return -EFAULT;
                        }
                    }
                }

                break;

            case DEVCTRL_RESET_ASYNC_NOTIFY:
                if (ctrl.args.reset_async_event.event == DEVCTRL_ASYNC_NOTIFY_DRIVER_CLOSED) {
                    if (ctrl.args.reset_async_event.ph == DEVCTRL_CLOSE_DRIVER_MAGIC) {
                        struct me_notification_handler * notify_handler;

                        spin_lock(&men->d6->notification_handler_headlock);
                        {
                            list_for_each_entry(notify_handler, &men->d6->notification_handler_heads, node) {
                                if (current->parent->pid == notify_handler->ppid) {
                                    notify_handler->quit_requested = true;
                                    complete( &notify_handler->notification_available);
                                }
                            }
                        }
                        spin_unlock(&men->d6->notification_handler_headlock);
                    }
                } else if (ctrl.args.reset_async_event.event == DEVCTRL_ASYNC_NOTIFY_DEVICE_ALARM) {
                    unsigned long alarms_to_ack = 0;

                    if (ctrl.args.reset_async_event.pl & DEVCTRL_DEVICE_ALARM_TEMPERATURE) {
                        if (ctrl.args.reset_async_event.ph != 0 &&
                                ctrl.args.reset_async_event.ph < LONG_MAX) {
                            men->d6->temperature_alarm_period = ctrl.args.reset_async_event.ph;
                            if (cancel_delayed_work(&men->d6->temperature_alarm_work)) {
                                schedule_delayed_work(&men->d6->temperature_alarm_work, msecs_to_jiffies(men->d6->temperature_alarm_period));
                            }
                        }

                        ctrl.args.reset_async_event.pl &= ~DEVCTRL_DEVICE_ALARM_TEMPERATURE;
                    }

                    alarms_to_ack = men->d6->event_pl_to_alarms(ctrl.args.reset_async_event.pl);

                    if (alarms_to_ack != 0) {
                        me6_ack_alarms(men, alarms_to_ack);
                    }
                }

                break;

            case DEVCTRL_SET_ASYNC_NOTIFY:
                if (ctrl.args.set_async_event.event == DEVCTRL_ASYNC_NOTIFY_DEVICE_ALARM) {

                    if (ctrl.args.reset_async_event.pl == DEVCTRL_DEVICE_ALARM_SOFTWARE) {
                        men->register_interface.write(&men->register_interface, ME6_REG_IRQ_SOFTWARE_TRIGGER, ctrl.args.reset_async_event.ph);
                    }
                }

                break;

            default:
                return -ENOSYS;
            }

            return result;
        }

    default:
        return -ENOIOCTLCMD;
    }
}

static void
me6_temperature_alarm_work(struct work_struct *work)
{
    struct me6_data *me6;

    me6 = container_of(to_delayed_work(work), struct me6_data, temperature_alarm_work);
    me6_ack_alarms(me6->men, me6->event_pl_to_alarms(DEVCTRL_DEVICE_ALARM_TEMPERATURE));
}

static void
me6_irq_notification_work(struct work_struct *work)
{
    struct me6_data *me6 = container_of(work, struct me6_data, irq_notification_work);
    uint32_t alarms_status = 0;
    unsigned long flags = 0;

    /* Notify all Notification Handlers */
    spin_lock(&me6->notification_handler_headlock);
    {
        struct me_notification_handler *notification_handler;
        list_for_each_entry(notification_handler, &me6->notification_handler_heads, node) {
            complete(&notification_handler->notification_available);
        }
    }
    spin_unlock(&me6->notification_handler_headlock);

    spin_lock_irqsave(&me6->notification_data_lock, flags);
    {
        alarms_status = me6->alarms_status;
    }
    spin_unlock_irqrestore(&me6->notification_data_lock, flags);

    /* Handle Temperature alarm */
    if (alarms_status & me6->event_pl_to_alarms(DEVCTRL_DEVICE_ALARM_TEMPERATURE)) {
        // Acknowledge & re-enable Temperature alarm after 1 second
        // (it might be already handled within this time)
        schedule_delayed_work(&me6->temperature_alarm_work, msecs_to_jiffies(me6->temperature_alarm_period));
    }
}

static void
me6_level_irq(struct siso_menable *men)
{
    unsigned long flags = 0;
    uint32_t status = men->register_interface.read(&men->register_interface, ME6_REG_IRQ_ALARMS_STATUS);

#if defined(DEBUG_IRQS)
    dev_info(&men->dev, "level interrupt sources: %08x\n", status);
#endif

    if (status != 0) {
        if (status & ME6_ALARM_SOFTWARE) {
            men->register_interface.write(&men->register_interface, ME6_REG_IRQ_SOFTWARE_TRIGGER, 0);
        }

        spin_lock_irqsave(&men->d6->notification_data_lock, flags);
        {
            men->d6->alarms_enabled &= ~status;
            men->d6->alarms_status |= status;
            men->d6->notifications |= NOTIFICATION_DEVICE_ALARM;
            men->d6->notification_time_stamp++;
            schedule_work(&men->d6->irq_notification_work);
        }
        spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);
    }
}

static void
me6_event_irq(struct siso_menable *men, struct timespec *ts, bool *have_ts)
{
    const uint32_t reg_content = men->register_interface.read(&men->register_interface, ME6_REG_IRQ_EVENT_COUNT);
    struct me6_data * me6 = men->d6;
    struct uiq_transfer_state * uiq_transfer = &me6->uiq_transfer;

    if ((reg_content & ME6_IRQ_EVENT_OVERFLOW) == 0) {
        uint32_t pending_irq_words = ME6_IRQ_EVENT_GET_COUNT(reg_content);
        while (pending_irq_words > 0) {

            if (uiq_transfer->remaining_packet_words == 0) {

                /*
                 * Get the next header
                 */
                uiq_transfer->current_header = men->register_interface.read(&men->register_interface, ME6_REG_IRQ_EVENT_DATA);
                --pending_irq_words;

                if (unlikely((uiq_transfer->current_header == 0) || (uiq_transfer->current_header == 0xffffffff))) {
                    dev_warn(&men->dev, "invalid event interrupt header received");
                    uiq_transfer->current_header = 0;
                    uiq_transfer->remaining_packet_words = 0;
                } else {
                    uiq_transfer->remaining_packet_words = ME6_IRQ_EVENT_GET_PACKET_LENGTH(uiq_transfer->current_header) - 1;

                    /* Get the target UIQ for the Interrupt */
                    uiq_transfer->current_uiq = NULL;
                    const uint32_t target_uiq_id = ME6_IRQ_EVENT_GET_PACKET_ID(uiq_transfer->current_header);
                    for (int i = 0; i < men->uiqcnt[0]; ++i) {
                         if (men->uiqs[i] && men->uiqs[i]->id == target_uiq_id) {
                             uiq_transfer->current_uiq = men->uiqs[i];
                             break;
                         }
                    }
                    if (uiq_transfer->current_uiq == NULL) {
                        dev_warn(&men->dev, "received data for invalid source id 0x%x; discarding %u words\n",
                                 target_uiq_id, uiq_transfer->remaining_packet_words);
                    }
                }
            } else {

                /*
                 * Process payload
                 */
                if (uiq_transfer->current_uiq != NULL) {
                    struct menable_uiq * uiq = uiq_transfer->current_uiq;

                    spin_lock(&uiq->lock);
                    if (UIQ_TYPE_IS_WRITE(uiq->type)) {
                        /* Receiving data on the write queue means that the queue is now empty. */
#if defined(DEBUG_IRQS)
                        dev_info(&men->dev, "received data for write queue, source id 0x%x; discarding %u words\n",
                                 uiq->id, uiq_transfer->remaining_packet_words);
#endif
                        while (pending_irq_words > 0 && uiq_transfer->remaining_packet_words > 0) {
                            (void)men->register_interface.read(&men->register_interface, ME6_REG_IRQ_EVENT_DATA);
                            --pending_irq_words;
                            --uiq_transfer->remaining_packet_words;
                        }

                        /* After receiving this packet, we may push more data to the device */
                        if (uiq_transfer->remaining_packet_words == 0) {
                            if (uiq->fill == 0) {
                                uiq->running = false;
                                uiq->rindex = 0;
                            } else {
                                (void)men_uiq_push(uiq);
                            }
                        }
                    } else {
                        enum uiq_protocol protocol = (ME6_IRQ_EVENT_GET_PACKET_TYPE(uiq_transfer->current_header) == ME6_EVENT_PACKET_TYPE_NATIVE)
                                                        ? UIQ_PROTOCOL_LEGACY
                                                        : UIQ_PROTOCOL_RAW;

                        /* Pop as much data from the device into local buffer as we have. */
#if defined(DEBUG_IRQS)
                        dev_info(&men->dev, "received data for read queue, source id 0x%x; reading %u words\n",
                                 uiq->id, uiq_transfer->remaining_packet_words);
#endif
                        while (pending_irq_words > 0 && uiq_transfer->remaining_packet_words > 0) {
                            (void)men_uiq_pop(uiq, ts, have_ts, protocol);
                            --pending_irq_words;
                            --uiq_transfer->remaining_packet_words;
                        }

                        if (uiq->cpltodo && (uiq->cpltodo <= uiq->fill)) {
                            complete(&uiq->cpl);
                        }
                        ++uiq->irqcnt;
                    }

                    spin_unlock(&uiq->lock);
                } else {
                   /* invalid UIQ, discard data */
                   while (pending_irq_words > 0 && uiq_transfer->remaining_packet_words > 0) {
                        (void) men->register_interface.read(&men->register_interface, ME6_REG_IRQ_EVENT_DATA);
                        --pending_irq_words;
                        --uiq_transfer->remaining_packet_words;
                    }
                }
            }
        }
    } else {
        dev_err(&men->dev, "overflow on event data fifo\n");
    }
}

static void
me6_dma_irq(struct siso_menable *men, int dma_idx, struct timespec *ts, bool *have_ts)
{
    uint32_t pending, count, i;
    struct menable_dma_wait *waiting;
    ktime_t timeout;

    struct menable_dmachan *dc = men_dma_channel(men, dma_idx);

    BUG_ON(dc == NULL);
    pending = men->register_interface.read(&men->register_interface, ME6_REG_IRQ_DMA_COUNT_FOR_CHANNEL_IDX(dma_idx));
    if ((pending & ME6_IRQ_DMA_OVERFLOW) == 0) {
        count = ME6_IRQ_DMA_GET_COUNT(pending);

        if (!*have_ts) {
            *have_ts = true;
            ktime_get_ts(ts);
        }

        spin_lock(&dc->chanlock);
        if (dc->active != NULL) {
            for (i = 0; i < count; ++i) {
                /* get latest buffer from hot list and move it to grabbed list */
                struct menable_dmabuf *sb = men_move_hot(dc, ts);
                uint32_t len = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_LENGTH);
                uint32_t tag = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_TAG);

                /* TODO [Documentation] Why is it unlikely that sb != NULL?
                 *      'count' is the number of acquired images, isn't it?
                 *      If so, it seems likely that there is a buffer behind sb.
                 */
                if (unlikely(sb != NULL)) {
                    sb->dma_length = len;
                    sb->dma_tag = tag;
                }
            }

            spin_lock(&dc->listlock);
            list_for_each_entry(waiting, &dc->wait_list, node) {
                /* TODO In a Unit Test, waiting can be NULL. Check this here or change the Test? */
                if (waiting->frame <= dc->goodcnt)
                    complete(&waiting->cpl);
            }

            if (likely(dc->transfer_todo > 0)) {
                if (count) {
                    men_dma_queue_max(dc);
                }

                spin_unlock(&dc->listlock);

                if (dc->timeout) {
                    timeout = ktime_set(dc->timeout, 0);
                    spin_lock(&dc->timerlock);
                    hrtimer_cancel(&dc->timer);
                    hrtimer_start(&dc->timer, timeout, HRTIMER_MODE_REL);
                    spin_unlock(&dc->timerlock);
                }
            } else {
                spin_unlock(&dc->listlock);
                dc->state = MEN_DMA_CHAN_STATE_IN_SHUTDOWN;
                schedule_work(&dc->dwork);
            }

        } else {
            for (i = 0; i < count; ++i) {
                uint32_t tmp = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_LENGTH);
                tmp = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_TAG);
                dc->lost_count++;
            }
        }

        spin_unlock(&dc->chanlock);
    } else {
        dev_err(&men->dev, "overflow on DMA channel %d\n", dc->number);
        dc->lost_count++;
    }
}

static void
me6_irq_dispatch(struct siso_menable *men, enum me6_irq_index irq_idx)
{
    bool have_ts = false;
    struct timespec ts;

    switch (irq_idx) {
    case ME6_IRQ_LEVEL_INDEX:
        {
#if defined(DEBUG_IRQS)
            dev_info(&men->dev, "level-triggered interrupt\n");
#endif
            me6_level_irq(men);
        }
        break;

    case ME6_IRQ_EVENT_INDEX:
        {
#if defined(DEBUG_IRQS)
            dev_info(&men->dev, "event interrupt\n");
#endif
            BUG_ON(men->uiqs == NULL);
            me6_event_irq(men, &ts, &have_ts);
        }
        break;

    case ME6_IRQ_DMA_0_INDEX:
    case ME6_IRQ_DMA_1_INDEX:
    case ME6_IRQ_DMA_2_INDEX:
    case ME6_IRQ_DMA_3_INDEX:
        {
            int dma_idx = irq_idx - ME6_IRQ_DMA_0_INDEX;
#if defined(DEBUG_IRQS)
            dev_info(&men->dev, "DMA %d interrupt\n", dma_idx);
#endif
            me6_dma_irq(men, dma_idx, &ts, &have_ts);
        }
        break;
    default:
        dev_warn(&men->dev, "unknown interrupt source %d\n", (int) irq_idx);
    }
}

static irqreturn_t
me6_irq(int irq, void *dev_id)
{
    struct siso_menable *men = (struct siso_menable *) dev_id;
    int i, found;

#if defined(DEBUG_IRQS)
    dev_dbg(&men->dev, "received interrupt %d\n", irq);
#endif

    if (pci_channel_offline(men->pdev)) {
        return IRQ_HANDLED;
    }

    if (men->active_fpgas == 0) {
        return IRQ_HANDLED;
    }

    if (men->d6->num_vectors > 1) {
        found = 0;
        for (i = 0; i < ME6_NUM_IRQS; ++i) {
            if (men->d6->vectors[i] == irq) {
                me6_irq_dispatch(men, i);
                found = 1;
                break;
            }
        }
    } else {
        uint32_t status = men->register_interface.read(&men->register_interface, ME6_REG_IRQ_STATUS);
        if (unlikely(status == (uint32_t) -1)) {
            dev_err(&men->dev, "failed to read interrupt status register\n");
            men_set_state(men, BOARD_STATE_DEAD);
            return IRQ_HANDLED;
        }

        found = 0;
        for (i = 0; i < ME6_NUM_IRQS; ++i) {
            if ((status & (1 << i)) != 0) {
                me6_irq_dispatch(men, i);
                found = 1;
                /* don't break here; handle all pending interrupts ... */
            }
        }
    }

    if (!found) {
        dev_err(&men->dev, "invalid interrupt source\n");
    }

    return IRQ_HANDLED;
}

static void
me6_set_sgl_entry(struct me6_sgl *sgl, int entry_idx, dma_addr_t addr,
                  u32 payload_size, u8 last)
{
    u64 temp;

    switch (entry_idx) {
    case 0:
        // d0[63:19] = addr[46:2], d0[18] = last, d[17:0] = rsvd
        temp = (last ? BIT_ULL(18) : 0) | msl64(addr, 46, 2, (19 - 2));
        sgl->data[0] = cpu_to_le64(temp);

        // d1[39:17] = size[22:0], d1[16:0] = addr[63:47]
        temp = le64_to_cpu(sgl->data[1]);
        temp = rmsr64(temp, addr, 63, 47, 47);
        temp = rmsl64(temp, payload_size, 22, 0, 17);
        sgl->data[1] = cpu_to_le64(temp);
        break;

    case 1:
        // d1[63:41] = addr[24:2], d1[40] = last
        temp = le64_to_cpu(sgl->data[1]);
        if (last) temp |= BIT_ULL(40); else temp &= ~BIT_ULL(40);
        temp = rmsl64(temp, addr, 24, 2, (41 - 2));
        sgl->data[1] = cpu_to_le64(temp);

        // d2[61:39] = size[22:0], d2[38:0] = addr[63:25]
        temp = le64_to_cpu(sgl->data[2]);
        temp = rmsr64(temp, addr, 63, 25, 25);
        temp = rmsl64(temp, payload_size, 22, 0, 39);
        sgl->data[2] = cpu_to_le64(temp);
        break;

    case 2:
        // d2[63] = addr[2], d2[62] = last
        temp = le64_to_cpu(sgl->data[2]);
        if (last) temp |= BIT_ULL(62); else temp &= ~BIT_ULL(62);
        temp = rmsl64(temp, addr, 2, 2, (63 - 2));
        sgl->data[2] = cpu_to_le64(temp);

        // d3[63:61] = size[2:0], d3[60:0] = addr[63:3]
        temp = msr64(addr, 63, 3, 3) | msl64(payload_size, 2, 0, 61);
        sgl->data[3] = cpu_to_le64(temp);

        // d4[19:0] = size[22:3]
        temp = le64_to_cpu(sgl->data[4]);
        temp = rmsr64(temp, payload_size, 22, 3, 3);
        sgl->data[4] = cpu_to_le64(temp);
        break;

    case 3:
        // d4[63:21] = addr[44:2], d4[20] = last
        temp = le64_to_cpu(sgl->data[4]);
        if (last) temp |= BIT_ULL(20); else temp &= ~BIT_ULL(20);
        temp = rmsl64(temp, addr, 44, 2, (21 - 2));
        sgl->data[4] = cpu_to_le64(temp);

        // d5[41:19] = size[22:0], d5[18:0] = addr[63:45]
        temp = le64_to_cpu(sgl->data[5]);
        temp = rmsr64(temp, addr, 63, 45, 45);
        temp = rmsl64(temp, payload_size, 22, 0, 19);
        sgl->data[5] = cpu_to_le64(temp);
        break;

    case 4:
        // d5[63:43] = addr[22:2], d5[42] = last
        temp = le64_to_cpu(sgl->data[5]);
        if (last) temp |= BIT_ULL(42); else temp &= ~BIT_ULL(42);
        temp = rmsl64(temp, addr, 22, 2, (43 - 2));
        sgl->data[5] = cpu_to_le64(temp);

        // d6[63:41] = size[22:0], d6[40:0] = addr[63:23]
        temp = msr64(addr, 63, 23, 23) | msl64(payload_size, 22, 0, 41);
        sgl->data[6] = cpu_to_le64(temp);
        break;

    default:
        BUG();
    }
}

#if defined(DEBUG_SGL)
static void
dumpsgl(struct me6_sgl *sgl)
{
    pr_info("dumping SGL block");
    pr_info("0: %016llx\n", sgl->next);
    for (unsigned int i = 0; i < 7; ++i) {
        pr_info("%d: %016llx\n", i+1, sgl->data[i]);
    }
}
#endif

static u32
me6_sgl_size(const u16 offset, const u32 size, const u32 payload)
{
    const u32 first_transfer_size = (offset % payload) == 0 ? payload : (payload - (offset % payload));

    u32 num_transfers;
    u32 last_transfer_size;

    /* See DmaSystemSpecification for mE6, pages 9 and 10 */
    if (size <= first_transfer_size) {
        num_transfers = 1;
        last_transfer_size = size;
    } else {
        const u32 aligned_transfer_size = size - first_transfer_size;

        num_transfers = 1 + (aligned_transfer_size / payload);
        last_transfer_size = aligned_transfer_size % payload;
        if (last_transfer_size == 0) {
            last_transfer_size = payload;
        } else {
            num_transfers += 1;
        }
    }

    /* Convert to number of 32bit words for the SGL */
    last_transfer_size /= 4;

    /* Yes, a value of BIT(15) for num_transfers, or BIT(8) for last_transfer, is allowed */
    /* It will be translated into 0, which means largest value (not 0!) to the firmware */
    BUG_ON(num_transfers > BIT(15) || last_transfer_size > BIT(8));

    return (num_transfers & GENMASK(14, 0)) | ((last_transfer_size & GENMASK(7, 0)) << (15));
}

static void
me6_free_sgl(struct siso_menable *men, struct menable_dmabuf *sb)
{
    struct men_dma_chain *res = sb->dma_chain;
    dma_addr_t dma = sb->dma;

#if defined(DEBUG_SGL)
    pr_info("destroying user buffer %ld\n", sb->index);
#endif

    while (res) {
        struct men_dma_chain *n;
        dma_addr_t ndma;

        n = res->next;
        ndma = (dma_addr_t) ((le64_to_cpu(res->pcie6->next) << 1) & ~(3ULL));
        if (dma == ndma) {
            break;
        }
        dma_pool_free(men->sgl_dma_pool, res->pcie6, dma);
        kfree(res);
        res = n;
        dma = ndma;
    }
}

static void
me6_queue_sb(struct menable_dmachan *db, struct menable_dmabuf *sb)
{
    w64(db->parent, db->iobase + ME6_REG_DMA_SGL_ADDR_LOW, (sb->dma >> 2));
    wmb();
}

static int
me6_create_userbuf(struct siso_menable * men, struct menable_dmabuf * dma_buf,
                   struct menable_dmabuf * dummybuf)
{
    const u32 payload_size = 128 << ((men->pcie_device_ctrl & GENMASK(7, 5)) >> 5);
    u64 remaining_length = dma_buf->buf_length;
    struct men_dma_chain *chain_node;
    int block_idx, block_entry_idx;

    dma_buf->dma_chain->pcie6 = dma_pool_alloc(men->sgl_dma_pool, GFP_USER, &dma_buf->dma);
    if (!dma_buf->dma_chain->pcie6)
        goto fail_pcie;

    memset(dma_buf->dma_chain->pcie6, 0, sizeof(*dma_buf->dma_chain->pcie6));

    chain_node = dma_buf->dma_chain;

#if defined(DEBUG_SGL)
    pr_info("creating user buffer %ld\n", dma_buf->index);
#endif

    block_idx = 0;
    block_entry_idx = 0;
    while (block_idx < dma_buf->num_sg_entries) {
#if defined(DEBUG_SGL)
        const unsigned int first_block_idx = block_idx;
#endif
        const dma_addr_t addr = sg_dma_address(dma_buf->sg + block_idx);
        unsigned int len = sg_dma_len(dma_buf->sg + block_idx);

        ++block_idx;

        /* Join contiguous blocks */
        while (block_idx < dma_buf->num_sg_entries
               && sg_dma_address(dma_buf->sg + block_idx) == (addr & ~0xfff) + 0x1000) {
            len += sg_dma_len(dma_buf->sg + block_idx);

            ++block_idx;
        }

        if (len > remaining_length) {
            len = (u32)remaining_length;
        }

        u8 is_last = block_idx < dma_buf->num_sg_entries ? 0 : 1;
        remaining_length -= len;

#if defined(DEBUG_SGL)
        pr_info("block %04d: address %016llx, length %08x, span %d\n", block_idx, (u64) addr, len, block_idx - first_block_idx);
#endif
        me6_set_sgl_entry(chain_node->pcie6, block_entry_idx, addr, me6_sgl_size(addr & 0xfff, len, payload_size), is_last);

        ++block_entry_idx;
        if ((block_entry_idx == ME6_SGL_ENTRIES) && !is_last) {
            /* block full, create next block and start over with entry 0 */
            block_entry_idx = 0;

            chain_node->next = kzalloc(sizeof(*chain_node->next), GFP_USER);
            if (!chain_node->next)
                goto fail;

            dma_addr_t next_block_address;
            chain_node->next->pcie6 = dma_pool_alloc(men->sgl_dma_pool, GFP_USER, &next_block_address);
            if (!chain_node->next->pcie6) {
                kfree(chain_node->next);
                chain_node->next = NULL;
                goto fail;
            }
            chain_node->pcie6->next = cpu_to_le64((next_block_address >> 1) | 0x1);
            chain_node = chain_node->next;
            memset(chain_node->pcie6, 0, sizeof(*chain_node->pcie6));
        }
    }

#if defined(DEBUG_SGL)
    chain_node = dma_buf->dma_chain;
    while (chain_node != NULL) {
        dumpsgl(chain_node->pcie6);
        chain_node = chain_node->next;
    }
#endif

    return 0;

fail:
    me6_free_sgl(men, dma_buf);
    return -ENOMEM;
fail_pcie:
    kfree(dma_buf->dma_chain);
    return -ENOMEM;
}

static int
me6_create_dummybuf(struct siso_menable *men, struct menable_dmabuf *dma_buf)
{
    struct men_dma_chain *dma_chain;
    int i;

    dma_buf->index = -1;
    dma_buf->dma_chain = kzalloc(sizeof(*dma_buf->dma_chain), GFP_KERNEL);
    if (!dma_buf->dma_chain) {
        goto fail_dma_chain;
    }

    dma_buf->dma_chain->pcie6 = dma_pool_alloc(men->sgl_dma_pool, GFP_USER, &dma_buf->dma);
    if (!dma_buf->dma_chain->pcie6) {
        goto fail_pcie;
    }

    memset(dma_buf->dma_chain->pcie6, 0, sizeof(*dma_buf->dma_chain->pcie6));

    dma_chain = dma_buf->dma_chain;

    for (i = 0; i < ME6_SGL_ENTRIES; i++) {
        me6_set_sgl_entry(dma_chain->pcie6, i, men->d6->dummypage_dma,
                          me6_sgl_size(0, PCI_PAGE_SIZE, men->d6->payload_size), 0);
    }

    dma_chain->pcie6->next = cpu_to_le64(dma_buf->dma >> 1 | 0x1);

    dma_buf->buf_length = -1;

    return 0;

fail_pcie:
    kfree(dma_buf->dma_chain);
fail_dma_chain:
    return -ENOMEM;
}

static void
me6_destroy_dummybuf(struct siso_menable *men, struct menable_dmabuf *db)
{
    dma_pool_free(men->sgl_dma_pool, db->dma_chain->pcie6, db->dma);
    kfree(db->dma_chain);
}

static void
me6_exit(struct siso_menable *men)
{
    int k;

    men->d6->cleanup_peripherals(men->d6);

    for (k = 0; k < men->d6->num_vectors; ++k) {
        devm_free_irq(&men->pdev->dev, men->d6->vectors[k], men);
        men->d6->vectors[k] = 0;
    }
    men->d6->num_vectors = 0;
    pci_free_irq_vectors(men->pdev);

    dmam_pool_destroy(men->sgl_dma_pool);
    pci_free_consistent(men->pdev, PCI_PAGE_SIZE, men->d6->dummypage, men->d6->dummypage_dma);

    kfree(men->uiqs);
    kfree(men->d6);
}

static unsigned int
me6_query_dma(struct siso_menable *men, const unsigned int arg)
{
    uint32_t num_dmas;

    BUG_ON(men->active_fpgas <= 0);

    num_dmas = men->register_interface.read(&men->register_interface, ME6_REG_NUM_DMA_CHANNELS);
    if (unlikely(num_dmas == (uint32_t) -1)) {
        dev_err(&men->dev, "failed to get number of DMAs\n");
        men_set_state(men, BOARD_STATE_DEAD);
        num_dmas = 0;
    }

    return num_dmas;
}

static void
me6_dmabase(struct siso_menable *men, struct menable_dmachan *dc)
{
    dc->iobase = ME6_REG_DMA_BASE + ME6_DMA_CHAN_OFFSET * dc->number;
    dc->irqack = 0;
    dc->ackbit = 0;
    dc->irqenable = 0;
    dc->enablebit = 0;
}

static void
me6_stopdma(struct siso_menable *men, struct menable_dmachan *dc)
{
    unsigned long timeout = ME6_DMA_STAT_TIMEOUT;
    uint32_t status;

    status = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_STATUS);
    dev_dbg(&men->dev, "%s - dma status = 0x%02x (enabled = %d, reset = %d, running = %d)\n",
            __FUNCTION__, status, status & 1, (status & 2) >> 1, (status & 4) >> 2);

    if (status & ME6_DMA_STAT_RUNNING) {
        men->register_interface.write(&men->register_interface, dc->iobase + ME6_REG_DMA_CONTROL, 0);
        do {
            status = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_STATUS);
            if (unlikely(status == (uint32_t) -1)) {
                dev_err(&men->dev, "failed to read DMA %d status register\n", dc->number);
                men_set_state(men, BOARD_STATE_DEAD);
                break;
            }
        } while ((status & ME6_DMA_STAT_RUNNING) != 0 && --timeout);

        if (timeout == 0) {
            dev_warn(&men->dev, "timed out while waiting for DMA %d to stop\n", dc->number);
            dev_dbg(&men->dev, "%s - dma status = 0x%02x (enabled = %d, reset = %d, running = %d)\n",
                    __FUNCTION__, status, status & 1, (status & 2) >> 1, (status & 4) >> 2);
        }
    }

}

static void
me6_abortdma(struct siso_menable *men, struct menable_dmachan *dc)
{
    me6_stopdma(men, dc);

    men->register_interface.write(&men->register_interface, dc->iobase + ME6_REG_DMA_CONTROL, ME6_DMA_CTRL_RESET);
    (void) men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_STATUS);

    men->register_interface.write(&men->register_interface, dc->iobase + ME6_REG_DMA_CONTROL, 0);
    (void) men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_STATUS);
}

static int
me6_startdma(struct siso_menable *men, struct menable_dmachan *dc)
{
    unsigned long timeout = ME6_DMA_STAT_TIMEOUT;
    uint32_t status;

    me6_abortdma(men, dc);
    men_dma_queue_max(dc);

    /* set channel to 'running' */
    men->register_interface.write(&men->register_interface, dc->iobase + ME6_REG_DMA_CONTROL, ME6_DMA_CTRL_ENABLE);

    /* check if status change has worked */
    do {
        status = men->register_interface.read(&men->register_interface, dc->iobase + ME6_REG_DMA_STATUS);
        if (unlikely(status == (uint32_t) -1)) {
            dev_err(&men->dev, "failed to read DMA channel %u status\n", (unsigned int) dc->number);
            men_set_state(men, BOARD_STATE_DEAD);
            return -EFAULT;
        }
    } while ((status & ME6_DMA_STAT_RUNNING) == 0 && --timeout);

    if (timeout == 0) {
        dev_err(&men->dev, "timed out while waiting for DMA %d to start\n", dc->number);
        return -ETIMEDOUT;
    }

    return 0;
}

static void
me6_stopirq(struct siso_menable *men)
{
    unsigned long flags;

    // Make sure that temperature alarm handling is not running
    if (!cancel_delayed_work(&men->d6->temperature_alarm_work)) {
        flush_delayed_work(&men->d6->temperature_alarm_work);
    }

    // Disable IRQ0 sources
    spin_lock_irqsave(&men->d6->notification_data_lock, flags);
    {
        men->d6->alarms_enabled = 0;
        men->register_interface.write(&men->register_interface, ME6_REG_IRQ_ALARMS_ENABLE, 0);
    }
    spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);

    // We might have scheduled another round of temperature alarm work in the meantime, so cancel again
    cancel_delayed_work(&men->d6->temperature_alarm_work);
}

static void
me6_startirq(struct siso_menable *men)
{
    unsigned long flags;

    if (men_get_state(men) >= BOARD_STATE_READY) {
        men->register_interface.write(&men->register_interface, ME6_REG_IRQ_SOFTWARE_TRIGGER, 0);

        // Enable IRQ0 sources
        spin_lock_irqsave(&men->d6->notification_data_lock, flags);
        {
            men->d6->alarms_enabled = men->d6->event_pl_to_alarms(0xffffffff);
            men->register_interface.write(&men->register_interface, ME6_REG_IRQ_ALARMS_ENABLE, men->d6->alarms_enabled);
        }
        spin_unlock_irqrestore(&men->d6->notification_data_lock, flags);
    }
}

static void
me6_cleanup(struct siso_menable *men)
{
    unsigned long flags;

    spin_lock_irqsave(&men->designlock, flags);
    {
        men->design_changing = true;
    }
    spin_unlock_irqrestore(&men->designlock, flags);

    memset(men->desname, 0, men->deslen);

    spin_lock_irqsave(&men->designlock, flags);
    {
        men->design_changing = false;
    }
    spin_unlock_irqrestore(&men->designlock, flags);
}

int
me6_add_uiqs(struct siso_menable * men, struct uiq_declaration * decls, unsigned int elems)
{
    int i, k;

    men->uiqs = kcalloc(elems, sizeof(*men->uiqs), GFP_KERNEL);
    if (men->uiqs == NULL) {
        return -ENOMEM;
    }

    for (i = 0; i < elems; ++i) {
        men->uiqs[i] = men_uiq_init(men, i, decls[i].id, decls[i].type, decls[i].reg_offs, decls[i].write_burst);

        if (IS_ERR(men->uiqs[i])) {
            int result = PTR_ERR(men->uiqs[i]);
            pr_err("failed to initialise UIQ %s (%d; error %d)\n", decls[i].name, decls[i].id, result);

            for (k = 0; k < i; ++k) {
                men_uiq_remove(men->uiqs[k]);
            }
            kfree(men->uiqs);
            men->uiqs = NULL;

            return result;
        }

        men_scale_uiq(men->uiqs[i], 100 * sizeof(*(men->uiqs[i]->data)));
    }

    men->uiqcnt[0] = elems;

    return 0;
}

int
me6_probe(struct siso_menable *men)
{
    int ret = 0, i, k;

    if (SisoBoardIsAbacus(men->pci_device_id)) {
        struct me6_abacus * me6 = kzalloc(sizeof(*me6), GFP_KERNEL);
        if (me6 == NULL) goto fail;
        ret = me6_abacus_init(men, me6);
        if (ret != 0) goto fail_init;
        men->d6 = upcast(me6);
    } else if (SisoBoardIsImpulse(men->pci_device_id)) {
        struct me6_impulse * me6 = kzalloc(sizeof(*me6), GFP_KERNEL);
        if (me6 == NULL) goto fail;
        ret = me6_impulse_init(men, me6);
        if (ret != 0) goto fail_init;
        men->d6 = upcast(me6);
    } else {
        dev_err(&men->dev, "failed to detect board variant.");
        goto fail;
    }

    men->d6->men = men;
    men->active_fpgas = 1;

    if (pci_set_dma_mask(men->pdev, DMA_BIT_MASK(64))) {
        dev_err(&men->dev, "failed to set DMA mask\n");
        goto fail_mask;
    }
    pci_set_consistent_dma_mask(men->pdev, DMA_BIT_MASK(64));

    men->sgl_dma_pool = dmam_pool_create("me6_sgl", &men->pdev->dev,
            sizeof(struct me6_sgl), 128, PCI_PAGE_SIZE);
    if (!men->sgl_dma_pool) {
        dev_err(&men->dev, "failed to allocate DMA pool\n");
        goto fail_pool;
    }

    men->d6->dummypage = pci_alloc_consistent(men->pdev, PCI_PAGE_SIZE, &men->d6->dummypage_dma);
    if (men->d6->dummypage == NULL) {
        dev_err(&men->dev, "failed to allocate dummy page\n");
        goto fail_dummy;
    }

    men->d6->payload_size = 128 << ((men->pcie_device_ctrl & GENMASK(7, 5)) >> 5);

    men->dma_fifo_length = ME6_DMA_SGL_ADDR_FIFO_DEPTH;

    men->create_dummybuf = me6_create_dummybuf;
    men->free_dummybuf = me6_destroy_dummybuf;
    men->create_buf = me6_create_userbuf;
    men->free_buf = me6_free_sgl;
    men->startdma = me6_startdma;
    men->abortdma = me6_abortdma;
    men->stopdma = me6_stopdma;
    men->stopirq = me6_stopirq;
    men->startirq = me6_startirq;
    men->ioctl = me6_ioctl;
    men->exit = me6_exit;
    men->cleanup = me6_cleanup;
    men->query_dma = me6_query_dma;
    men->dmabase = me6_dmabase;
    men->queue_sb = me6_queue_sb;

    men->d6->temperature_alarm_period = 1000;

    INIT_LIST_HEAD(&men->d6->notification_handler_heads);
    INIT_DELAYED_WORK(&men->d6->temperature_alarm_work, me6_temperature_alarm_work);
    INIT_WORK(&men->d6->irq_notification_work, me6_irq_notification_work);

    men->desname = men->d6->design_name;
    men->deslen = sizeof(men->d6->design_name);

    me6_stopirq(men);

    /* It's either all MSI-X vectors, or one single */
    ret = pci_alloc_irq_vectors(men->pdev, ME6_NUM_IRQS, ME6_NUM_IRQS, PCI_IRQ_MSIX);
    if (ret == ME6_NUM_IRQS) {
        men->d6->num_vectors = ME6_NUM_IRQS;
        dev_info(&men->dev, "allocated %d interrupt vectors\n", men->d6->num_vectors);
    } else {
        dev_info(&men->dev, "failed to allocate %d interrupt vectors; falling back to one\n", ME6_NUM_IRQS);
        ret = pci_alloc_irq_vectors(men->pdev, 1, 1, PCI_IRQ_MSIX);
        if (ret == 1) {
            men->d6->num_vectors = 1;
        } else {
            dev_err(&men->dev, "failed to allocate any interrupt vectors\n");
            dev_info(&men->dev, "this might be due to MSI-X not enabled in kernel config, or too many MSI-X resources in use");
            goto fail_irq_alloc;
        }
    }

    /* Setup IRQs */
    for (i = 0; i < men->d6->num_vectors; ++i) {
        ret = pci_irq_vector(men->pdev, i);
        if (ret >= 0) {
            men->d6->vectors[i] = ret;
            ret = devm_request_irq(&men->pdev->dev, men->d6->vectors[i], me6_irq, 0, DRIVER_NAME, men);
        }

        if (ret != 0) {
            dev_err(&men->dev, "failed to request interrupt vector %d\n", i);
            for (k = 0; k < i; ++k) {
                devm_free_irq(&men->pdev->dev, men->d6->vectors[k], men);
                men->d6->vectors[k] = 0;
            }
            men->d6->vectors[i] = 0;
            goto fail_irq_request;
        }
    }

    ret = MCapLibInit(&men->d6->mdev, upcast(&men->config_interface));
    if (ret != 0) {
        goto fail_state;
    }

    ret = MCapFullReset(&men->d6->mdev);
    if (ret != 0) {
        goto fail_state;
    }

    ret = me6_update_board_status(men);
    if (ret) {
        goto fail_state;
    }

    if (men_get_state(men) >= BOARD_STATE_READY) {
        ret = men->d6->init_peripherals(men->d6);

        // Reset the camera frontend to get into a defined state.
        mutex_lock(&men->camera_frontend_lock);
        if (men->camera_frontend != NULL) {
            men->camera_frontend->reset(men->camera_frontend);
        }
        mutex_unlock(&men->camera_frontend_lock);
    }

    return 0;

fail_state:
    for (k = 0; k < men->d6->num_vectors; ++k) {
        devm_free_irq(&men->pdev->dev, men->d6->vectors[k], men);
        men->d6->vectors[k] = 0;
    }
    men->d6->num_vectors = 0;
fail_irq_request:
    pci_free_irq_vectors(men->pdev);
fail_irq_alloc:
    pci_free_consistent(men->pdev, PCI_PAGE_SIZE, men->d6->dummypage, men->d6->dummypage_dma);
fail_dummy:
    dmam_pool_destroy(men->sgl_dma_pool);
fail_pool:
fail_mask:
    men_del_uiqs(men, 0);
    kfree(men->uiqs);
fail_init:
    kfree(men->d6);
fail:
    return ret;
}
